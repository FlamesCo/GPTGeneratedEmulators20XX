import tkinter as tk
from tkinter import ttk
from tkinter import filedialog

class EmulatorGUI:
    def __init__(self, root):
        self.root = root
        self.root.geometry("800x600")  # set window size
        self.root.title("EMUCONSOLE V0.X.XA")  # set window title

        # Example game files dictionary
        self.game_files = {}
        self.wii_bios = None

        # create widgets
        self.menu_bar = tk.Menu(self.root)
        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.help_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.emulator_frame = ttk.Frame(self.root)
        self.game_listbox = ttk.Treeview(self.emulator_frame)
        self.play_button = ttk.Button(self.emulator_frame, text="Play", command=self.play_game)

        # configure Treeview (game_listbox) columns
        self.game_listbox["columns"] = ("Title", "File")
        self.game_listbox.column("#0", width=0, stretch=tk.NO)
        self.game_listbox.column("Title", anchor=tk.W, width=200)
        self.game_listbox.column("File", anchor=tk.W, width=200)
        self.game_listbox.heading("#0", text="", anchor=tk.W)
        self.game_listbox.heading("Title", text="Title", anchor=tk.W)
        self.game_listbox.heading("File", text="Wii File", anchor=tk.W)

        # add widgets to window
        self.root.config(menu=self.menu_bar)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="Add game", command=self.add_game)
        self.file_menu.add_command(label="Load Wii BIOS", command=self.load_wii_bios)
        self.menu_bar.add_cascade(label="Help", menu=self.help_menu)
        self.emulator_frame.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)
        self.game_listbox.pack(expand=True, fill=tk.BOTH, side=tk.LEFT)
        self.play_button.pack(side=tk.BOTTOM, pady=10)

    def add_game(self):
        file_path = filedialog.askopenfilename(filetypes=[("Wii files", "*.wii")])
        if not file_path:
            return

        game_title = input("Enter the game title: ")
        self.game_files[game_title] = file_path
        self.game_listbox.insert("", "end", text="", values=(game_title, file_path))

    def load_wii_bios(self):
        bios_path = filedialog.askopenfilename(filetypes=[("Wii BIOS", "*.bios")])
        if not bios_path:
            return

        self.wii_bios = bios_path
        print(f"Wii BIOS loaded from {bios_path}")

    def play_game(self):
        if not self.wii_bios:
            print("Wii BIOS not loaded. Please load Wii BIOS before playing.")
            return

        selected_game = self.game_listbox.focus()
        if not selected_game:
            return

        game_info = self.game_listbox.item(selected_game)
        game_title, game_file = game_info["values"]
        print(f"Playing {game_title} from {game_file} using BIOS {self.wii_bios}")
        # Call your emulator backend to load and play the game file using the Wii BIOS here

if __name__ == "__main__":
    root = tk.Tk()
    EmulatorGUI(root)
    root.mainloop()